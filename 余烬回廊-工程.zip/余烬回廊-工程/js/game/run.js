/* 余烬回廊 · 流程
   项目结构见 README.md；本文件为普通脚本，按 index 中的顺序加载。 */
/* ---------------- 12. 局内流程 ---------------- */
function startRun() {
  g.player = newPlayer();
  g.run = { crystals: 0, cores: 0, rerolls: 2, totems: [], boss: null };
  g.enemies = []; g.bullets = []; g.ebullets = []; g.zones = [];
  g.texts = []; g.parts = []; g.shake = 0; g.banner = null; g.warn = 0;
  g.elapsed = 0; g.cleared = false; g.pending = null; g.bossDead = false;
  meta.runs++; saveMeta();
  renderSkillbar();
  hideOverlay();
  startStage(1);
}
function startStage(n) {
  g.stage = n;
  const R = ROOMS[n - 1];
  $('roomName').textContent = R.name;
  g.enemies = []; g.bullets = []; g.ebullets = []; g.zones = [];
  g.roomT = 0; g.wave = 0; g.waveT = 0; g.cleared = false; g.pending = null; g.warn = 0;
  g.texts = [];
  if (R.choice) { g.state = 'choice'; openChoice(); return; }
  g.state = 'playing';
  spawnWave();
}
function spawnWave() {
  const R = ROOMS[g.stage - 1];
  if (!R.waves) return;
  const w = R.waves[g.wave];
  w.forEach(s => { for (let i = 0; i < s.n; i++) spawnEnemy(s.t, R.hp[s.t] || 40); });
  if (R.crystals && g.wave === 0) {
    const els = ELK.slice().sort(() => Math.random() - 0.5).slice(0, 2);
    els.forEach((el, i) => spawnEnemy('cr', 1, { x: i ? 660 : 300, y: 300, crystalEl: el, r: 15 }));
  }
}
function roomTick(dt) {
  const R = ROOMS[g.stage - 1];
  if (!R || R.choice) return;
  g.roomT += dt;
  if (R.lim && g.roomT > R.lim) {
    g.warn = 1;
    g.player.hp -= g.player.maxHp * 0.012 * dt;
    if (g.player.hp <= 0) { g.player.hp = 1; }
    if (Math.random() < 0.02) floatText(g.player.x, g.player.y - 30, '侵蚀', '#ff6b3d');
  }
  if (g.waveT > 0) {
    g.waveT -= dt;
    if (g.waveT <= 0) spawnWave();
    return;
  }
  if (g.enemies.filter(e => !e.dead && e.type !== 'cr').length === 0 && !g.cleared) {
    if (g.wave < R.waves.length - 1) {
      g.wave++; g.waveT = 0.8;
      floatText(W / 2, 74, '第 ' + (g.wave + 1) + ' 波', '#c9a227');
    } else {
      g.cleared = true;
      roomClear();
    }
  }
}
function roomClear() {
  g.state = 'cleared';
  const bonus = 5 + g.stage * 3;
  g.run.crystals += bonus;
  healPlayer(g.player.maxHp * 0.3);
  g.pending = { t: 0.9, fn: openDraft };
}
function startBoss() {
  g.stage = 6;
  g.enemies = []; g.zones = []; g.bullets = []; g.roomT = 0; g.wave = 1;
  $('roomName').textContent = '终局 · 回廊之主';
  const b = spawnEnemy('boss', 12000, { x: W / 2, y: 160 });
  b.phase = 1;
  g.run.boss = b;
  g.state = 'playing';
  g.banner = { name: '回廊之主', color: '#ff5a3c', txt: '击碎它，回廊才会结束', t: 2.0 };
}
