/* 余烬回廊 · 三选一
   项目结构见 README.md；本文件为普通脚本，按 index 中的顺序加载。 */
/* ---------------- 13. 三选一 ---------------- */
function rollDraft(n) {
  const owned = new Set([...g.player.skills.map(s => s.ref.id), ...g.player.passives.map(s => s.id)]);
  let pool = meta.unlocked.map(id => SKMAP[id]).filter(s => s && !owned.has(s.id));
  if (!pool.length) pool = SKILLS.filter(s => !owned.has(s.id));
  if (!pool.length) return [];
  const wf = s => {
    let x = s.rar === 3 ? 0.45 : s.rar === 2 ? 0.9 : 1.2;
    if (s.el && meta.prefs.includes(s.el)) x *= 1.6;
    if (g.stage >= 3 && s.rar === 3) x *= 1.5;
    return x;
  };
  const ownEls = new Set(g.player.skills.map(s => s.ref.el).filter(Boolean));
  const out = [];
  if (ownEls.size < 4) {
    const np = pool.filter(s => s.el && !ownEls.has(s.el));
    if (np.length) out.push(pick(np));
  }
  while (out.length < n) {
    const rest = pool.filter(s => !out.includes(s));
    if (!rest.length) break;
    out.push(wp(rest, wf));
  }
  return out;
}
function wp(list, wf) {
  const tot = list.reduce((a, s) => a + wf(s), 0);
  let r = Math.random() * tot;
  for (const s of list) { r -= wf(s); if (r <= 0) return s; }
  return list[list.length - 1];
}
function syncCount(sk) {
  if (!sk.el) return 0;
  const els = new Set(g.player.skills.map(s => s.ref.el).filter(Boolean));
  let c = 0;
  els.forEach(e => { if (e !== sk.el) c++; });
  return c;
}
function carriedText() {
  const els = [...new Set(g.player.skills.map(s => s.ref.el).filter(Boolean))];
  return els.length ? els.map(e => EL[e].name).join(' · ') : '无元素';
}
function openDraft() {
  g.state = 'draft';
  const opts = rollDraft(3);
  const o = $('overlay');
  o.innerHTML = `<div class="panel">
    <h2>三选一 · 第 ${g.stage} 次抉择</h2>
    <div class="sub">不同元素命中同一目标才会触发反应。当前元素：<span style="color:#e8e1d3">${carriedText()}</span></div>
    <div class="cards"></div>
    <div class="btnrow" style="margin-top:18px">
      <button class="btn ghost" id="rr1">免费重掷（剩 ${g.run.rerolls}）</button>
      <button class="btn ghost" id="rr2" ${g.run.crystals >= 25 ? '' : 'disabled'}>花 25 尘晶重掷</button>
    </div>
    <div class="sub" style="margin:14px 0 0">技能槽 ${g.player.skills.length}/5 · 被动 ${g.player.passives.length} 个</div>
  </div>`;
  o.classList.add('show');
  const box = o.querySelector('.cards');
  if (!opts.length) { box.innerHTML = '<div class="sub">技能池已空。</div>'; }
  opts.forEach(sk => box.appendChild(cardEl(sk)));
  $('rr1').onclick = () => {
    if (g.run.rerolls <= 0) return;
    g.run.rerolls--; openDraft();
  };
  $('rr2').onclick = () => {
    if (g.run.crystals < 25) return;
    g.run.crystals -= 25; openDraft();
  };
}
function cardEl(sk) {
  const d = document.createElement('div');
  const c = sk.el ? EL[sk.el].color : '#c9a227';
  const sync = syncCount(sk);
  d.className = 'card';
  d.style.setProperty('--c', c);
  d.innerHTML = `
    <div class="rar">${'★'.repeat(sk.rar)}</div>
    ${sync ? `<div class="sync">联动 ×${sync}</div>` : ''}
    <h3>${sk.name}</h3>
    <div class="el" style="color:${c}">${sk.el ? EL[sk.el].name + ' · ' + (sk.kind === 'passive' ? '规则' : '主动') : '秘 · 规则'}</div>
    <div class="d">${sk.desc}</div>
    <div class="p">${sk.kind === 'passive' ? (sk.pasTxt || '') : (sk.cd ? '冷却 ' + sk.cd + 's　' : '') + PASK[sk.pas].txt}</div>`;
  d.onclick = () => pickSkill(sk);
  return d;
}
function pickSkill(sk) {
  addSkill(sk);
  renderSkillbar();
  hideOverlay();
  afterDraft();
}
function afterDraft() {
  if (g.stage >= 5) startBoss();
  else startStage(g.stage + 1);
}
