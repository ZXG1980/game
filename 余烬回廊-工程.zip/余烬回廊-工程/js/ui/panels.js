/* 余烬回廊 · 界面面板
   项目结构见 README.md；本文件为普通脚本，按 index 中的顺序加载。 */
/* ---------------- 14. 抉择房 / 商店 / 篝火 / 宝箱 ---------------- */
function openChoice() {
  g.state = 'choice';
  const o = $('overlay');
  o.innerHTML = `<div class="panel">
    <h2>抉择之室</h2>
    <div class="sub">三扇门，只能开一扇。你身上有 ${g.run.crystals} 尘晶。</div>
    <div class="cards">
      <div class="card" style="--c:#c9a227" id="d1">
        <div class="rar">门一</div><h3>商店</h3>
        <div class="el" style="color:#c9a227">消耗尘晶</div>
        <div class="d">买技能、买补给、买护符。钱花在这里，就不会带回局外。</div>
        <div class="p">三件商品，明码标价</div>
      </div>
      <div class="card" style="--c:#8bd450" id="d2">
        <div class="rar">门二</div><h3>篝火</h3>
        <div class="el" style="color:#8bd450">免费</div>
        <div class="d">回复 45% 生命，或把已有技能升阶（效果 +30%）。</div>
        <div class="p">只能二选一</div>
      </div>
      <div class="card" style="--c:#4fc3f7" id="d3">
        <div class="rar">门三</div><h3>宝箱</h3>
        <div class="el" style="color:#4fc3f7">有风险</div>
        <div class="d">白拿 1~2 枚元素核心。30% 是陷阱箱：扣 20% 生命换双倍核心。</div>
        <div class="p">局外成长最快的来源</div>
      </div>
    </div></div>`;
  o.classList.add('show');
  $('d1').onclick = openShop;
  $('d2').onclick = openRest;
  $('d3').onclick = openChest;
}
function openShop() {
  const owned = new Set([...g.player.skills.map(s => s.ref.id), ...g.player.passives.map(s => s.id)]);
  let pool = meta.unlocked.map(id => SKMAP[id]).filter(s => s && !owned.has(s.id));
  const goods = [];
  if (pool.length) goods.push({ t: 'skill', sk: pick(pool), price: 45, label: '技能' });
  goods.push({ t: 'heal', price: 25, label: '烬疗', desc: '回复 45% 生命' });
  if (!g.player.amulet) goods.push({ t: 'amulet', price: 40, label: '余烬护符', desc: '致死时满血复活一次' });
  const o = $('overlay');
  o.innerHTML = `<div class="panel">
    <h2>商店</h2>
    <div class="sub">持有 ${g.run.crystals} 尘晶。离店后剩余尘晶仅 60% 折算入局外。</div>
    <div class="cards">${goods.map((it, i) => `
      <div class="card" style="--c:${it.sk && it.sk.el ? EL[it.sk.el].color : '#c9a227'}" data-buy="${i}">
        <div class="rar">${it.price} 尘晶</div>
        <h3>${it.t === 'skill' ? it.sk.name : it.label}</h3>
        <div class="el" style="color:#c9a227">${it.t === 'skill' ? (EL[it.sk.el].name + ' · ' + it.sk.cd + 's') : '补给'}</div>
        <div class="d">${it.t === 'skill' ? it.sk.desc : it.desc}</div>
        <div class="p">${it.t === 'skill' ? PASK[it.sk.pas].txt : '立即生效'}</div>
      </div>`).join('')}</div>
    <div class="btnrow" style="margin-top:18px"><button class="btn ghost" id="leave">离开商店</button></div>
  </div>`;
  o.classList.add('show');
  o.querySelectorAll('[data-buy]').forEach(node => {
    node.onclick = () => {
      const it = goods[+node.dataset.buy];
      if (g.run.crystals < it.price) { node.style.filter = 'grayscale(1)'; return; }
      g.run.crystals -= it.price;
      if (it.t === 'skill') { addSkill(it.sk); renderSkillbar(); }
      if (it.t === 'heal') healPlayer(g.player.maxHp * 0.45);
      if (it.t === 'amulet') g.player.amulet = true;
      openShop();
    };
  });
  $('leave').onclick = () => openDraft();
}
function openRest() {
  const o = $('overlay');
  o.innerHTML = `<div class="panel">
    <h2>篝火</h2>
    <div class="sub">火焰只够做一件事。</div>
    <div class="btnrow">
      <button class="btn primary" id="heal">回复 45% 生命</button>
      <button class="btn" id="up">升阶一个技能（+30% 效果）</button>
    </div>
    <div class="cards" style="margin-top:16px" id="upList"></div>
  </div>`;
  o.classList.add('show');
  $('heal').onclick = () => { healPlayer(g.player.maxHp * 0.45); openDraft(); };
  $('up').onclick = () => {
    const list = $('upList');
    if (!g.player.skills.length) { list.innerHTML = '<div class="sub">还没有主动技能。</div>'; return; }
    list.innerHTML = '';
    g.player.skills.forEach((s, i) => {
      const d = document.createElement('div');
      d.className = 'card';
      d.style.setProperty('--c', s.ref.el ? EL[s.ref.el].color : '#c9a227');
      d.innerHTML = `<h3>${s.ref.name} <span style="font-size:12px;color:#8a8272">Lv.${s.lv}</span></h3>
        <div class="d">${s.ref.desc}</div><div class="p">升阶后效果 +30%</div>`;
      d.onclick = () => { s.lv++; floatText(g.player.x, g.player.y - 30, s.ref.name + ' 升阶', '#c9a227'); openDraft(); };
      list.appendChild(d);
    });
  };
}
function openChest() {
  const trap = Math.random() < 0.3;
  const cores = trap ? 2 : ri(1, 2);
  if (trap) hurtPlayer(g.player.maxHp * 0.2);
  g.run.cores += cores;
  const o = $('overlay');
  o.innerHTML = `<div class="panel">
    <h2>宝箱</h2>
    <div class="sub">${trap ? '箱底弹出一道余烬，灼伤了你的手。' : '锁扣自行弹开，里面是凝成实体的元素残渣。'}</div>
    <div class="result"><div>获得核心<b>+${cores}</b></div><div>生命<b>${Math.ceil(g.player.hp)}</b></div></div>
    <div class="btnrow"><button class="btn primary" id="ok">继续</button></div></div>`;
  o.classList.add('show');
  $('ok').onclick = () => openDraft();
}

/* ---------------- 15. 结算 ---------------- */
function gameOver() {
  if (g.player.amulet) {
    g.player.amulet = false;
    g.player.hp = g.player.maxHp;
    g.player.inv = 1.2;
    g.banner = { name: '余烬护符', color: '#ffd166', txt: '你被从灰里捞了回来', t: 1.6 };
    return;
  }
  if (g.state !== 'playing') return;
  g.state = 'dead';
  finishRun(false);
}
function victory() {
  if (g.state === 'win') return;
  g.state = 'win';
  finishRun(true);
}
function finishRun(win) {
  const left = g.run.crystals;
  const bank = Math.round(left * 0.6) + (g.stage >= 5 ? 25 : 0) + (win ? 60 : 0);
  meta.crystals += bank;
  meta.cores += g.run.cores;
  if (win) meta.clears++;
  saveMeta();
  const o = $('overlay');
  o.innerHTML = `<div class="panel">
    <h2>${win ? '回廊终结' : '倒在' + (g.stage <= 5 ? ROOMS[g.stage - 1].name : '回廊之主面前')}</h2>
    <div class="sub">${win ? '余烬散尽。你带走了它的一部分。' : '死在这里不算彻底失败 —— 未花掉的尘晶仍有六成归你。'}</div>
    <div class="result">
      <div>局内剩余尘晶<b>${left}</b></div>
      <div>折算入账<b>+${bank}</b></div>
      <div>元素核心<b>+${g.run.cores}</b></div>
      <div>用时<b>${fmt(g.elapsed)}</b></div>
    </div>
    <div class="btnrow" style="margin-top:18px">
      <button class="btn primary" id="again">再来一局</button>
      <button class="btn ghost" id="hall">回到大厅</button>
    </div></div>`;
  o.classList.add('show');
  $('again').onclick = startRun;
  $('hall').onclick = openTitle;
}
function fmt(t) {
  const m = Math.floor(t / 60), s = Math.floor(t % 60);
  return m + ':' + String(s).padStart(2, '0');
}
function hideOverlay() {
  const o = $('overlay');
  if (!o) return;
  o.classList.remove('show');
  o.innerHTML = '';
}

/* ---------------- 16. 大厅 / 图鉴 ---------------- */
function openTitle() {
  g.state = 'title';
  g.player = null;
  renderSkillbar();
  const o = $('overlay');
  o.innerHTML = `<div class="panel" style="text-align:center">
    <div style="font-size:11px;letter-spacing:.4em;color:#7d7565;margin-bottom:6px">EMBER CORRIDOR</div>
    <h2 style="font-size:34px;letter-spacing:.22em;margin-bottom:10px">余 烬 回 廊</h2>
    <div class="sub" style="margin-bottom:20px">每局 10 分钟 · 5 个房间 · 每次都从 3 张卡里选 1 张<br>不同元素打在同一目标上，才会发生反应</div>
    <div class="result" style="justify-content:center">
      <div>尘晶<b>${meta.crystals}</b></div>
      <div>核心<b>${meta.cores}</b></div>
      <div>通关<b>${meta.clears}</b></div>
      <div>已解锁技能<b>${meta.unlocked.length}/${SKILLS.length}</b></div>
    </div>
    <div class="btnrow" style="justify-content:center;margin-top:20px">
      <button class="btn primary" id="b1">开始一局</button>
      <button class="btn" id="b2">技能图鉴</button>
      <button class="btn ghost" id="b3">玩法说明</button>
    </div>
    <div class="sub" style="margin-top:16px;font-size:11px">WASD / 方向键移动 · 空格冲刺 · 1-5 放技能 · 触屏可拖拽移动</div>
  </div>`;
  o.classList.add('show');
  $('b1').onclick = startRun;
  $('b2').onclick = openMeta;
  $('b3').onclick = openRules;
}
function openRules() {
  const rows = [['fire','ice'],['fire','bolt'],['fire','venom'],['ice','bolt'],['ice','venom'],['bolt','venom']];
  const o = $('overlay');
  o.innerHTML = `<div class="panel">
    <h2>玩法说明</h2>
    <div class="sub">四种元素、六种反应。技能命中会给目标挂印记；<b style="color:#e8e1d3">再用另一种元素打上去</b>，反应立刻结算。</div>
    <div class="skillrow"><div class="nm2">印记</div><div class="ds2">火=灼（持续掉血）　冰=寒（减速，3 层冻结）　雷=导（弹射）　毒=蚀（受伤 +8%/层）</div></div>
    ${rows.map(([a, b]) => {
      const r = rk(a, b);
      return `<div class="skillrow"><div class="dot" style="background:${r.color}"></div>
        <div class="nm2" style="color:${r.color}">${r.name}</div>
        <div class="ds2">${EL[a].name} + ${EL[b].name} —— ${r.txt}</div></div>`;
    }).join('')}
    <div class="sub" style="margin-top:16px">房间 4 是三选一的抉择室（商店 / 篝火 / 宝箱）。第 5 个房间后是 Boss：二阶段会召唤四枚图腾，你需要两种不同元素才能全部击碎。</div>
    <div class="btnrow"><button class="btn" id="back">返回</button></div></div>`;
  o.classList.add('show');
  $('back').onclick = openTitle;
}
function openMeta() {
  const o = $('overlay');
  const prefs = meta.prefs;
  o.innerHTML = `<div class="panel">
    <h2>技能图鉴</h2>
    <div class="sub">尘晶 <b style="color:#c9a227">${meta.crystals}</b> · 核心 <b style="color:#c9a227">${meta.cores}</b>　解锁后进入随机池。
      偏好元素（最多 2 个，抽卡权重 ×1.6）：${ELK.map(k => `<a href="javascript:void 0" data-pref="${k}" style="margin-left:6px;padding:1px 8px;border:1px solid ${prefs.includes(k) ? EL[k].color : '#33302a'};color:${prefs.includes(k) ? EL[k].color : '#7d7565'};text-decoration:none">${EL[k].name}</a>`).join('')}</div>
    <div id="list"></div>
    <div class="btnrow" style="margin-top:18px"><button class="btn" id="back">返回大厅</button>
      <button class="btn ghost" id="reset">清空存档</button></div></div>`;
  o.classList.add('show');
  const list = $('list');
  ELK.forEach(k => {
    const h = document.createElement('div');
    h.className = 'sub';
    h.style.margin = '12px 0 2px';
    h.innerHTML = `<span style="color:${EL[k].color}">■</span> ${EL[k].name}系`;
    list.appendChild(h);
    SKILLS.filter(s => s.el === k).forEach(s => list.appendChild(skillRow(s)));
  });
  const h2 = document.createElement('div');
  h2.className = 'sub'; h2.style.margin = '14px 0 2px'; h2.textContent = '■ 规则型（紫）';
  list.appendChild(h2);
  SKILLS.filter(s => s.rar === 3).forEach(s => list.appendChild(skillRow(s)));
  $('back').onclick = openTitle;
  $('reset').onclick = () => {
    if (!confirm('清空全部局外进度？')) return;
    meta = JSON.parse(JSON.stringify(DEFAULT_META)); saveMeta(); openMeta();
  };
  o.querySelectorAll('[data-pref]').forEach(a => {
    a.onclick = () => {
      const k = a.dataset.pref;
      if (prefs.includes(k)) meta.prefs = prefs.filter(x => x !== k);
      else if (prefs.length < 2) meta.prefs = prefs.concat(k);
      saveMeta(); openMeta();
    };
  });
}
function skillRow(s) {
  const on = meta.unlocked.includes(s.id);
  const cost = costOf(s);
  const c = s.el ? EL[s.el].color : '#c9a227';
  const row = document.createElement('div');
  row.className = 'skillrow';
  row.innerHTML = `<div class="dot" style="background:${on ? c : '#3a352c'}"></div>
    <div class="nm2">${s.name}<span style="color:#6b6558;font-size:11px"> ${'★'.repeat(s.rar)}</span></div>
    <div class="ds2">${on ? s.desc : '未解锁 · ' + cost.c + ' 尘晶' + (cost.k ? ' + ' + cost.k + ' 核心' : '')}</div>
    <div class="btns">${on ? '<span style="color:#5f8f4a;font-size:11px">已解锁</span>'
      : `<button class="btn" style="padding:5px 12px;font-size:11px" data-unlock="${s.id}">解锁</button>`}</div>`;
  if (!on) {
    row.querySelector('[data-unlock]').onclick = () => {
      if (meta.crystals < cost.c || meta.cores < cost.k) return;
      meta.crystals -= cost.c; meta.cores -= cost.k;
      meta.unlocked.push(s.id); saveMeta(); openMeta();
    };
  }
  return row;
}
