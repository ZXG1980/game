/* 余烬回廊 · 渲染
   项目结构见 README.md；本文件为普通脚本，按 index 中的顺序加载。 */
/* ---------------- 17. 绘制 ---------------- */
function poly(x, y, r, n, rot) {
  ctx.beginPath();
  for (let i = 0; i < n; i++) {
    const a = rot + i / n * TAU;
    const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
    i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
  }
  ctx.closePath();
}
const embers = [];
for (let i = 0; i < 26; i++) embers.push({ x: rnd(0, W), y: rnd(0, H), v: rnd(8, 26), s: rnd(1, 2.4), p: rnd(0, TAU) });
function drawEmbers(dt) {
  embers.forEach(e => {
    e.y -= e.v * dt; e.x += Math.sin(g.t * 0.6 + e.p) * 6 * dt;
    if (e.y < -10) { e.y = H + 10; e.x = rnd(0, W); }
    ctx.globalAlpha = 0.25 + Math.sin(g.t * 2 + e.p) * 0.12;
    ctx.fillStyle = '#ff8f5e';
    ctx.beginPath(); ctx.arc(e.x, e.y, e.s, 0, TAU); ctx.fill();
    ctx.globalAlpha = 1;
  });
}
function drawBg() {
  const grd = ctx.createRadialGradient(W / 2, H * 0.42, 40, W / 2, H * 0.42, 640);
  grd.addColorStop(0, '#141a24'); grd.addColorStop(0.55, '#0a0e14'); grd.addColorStop(1, '#05070a');
  ctx.fillStyle = grd; ctx.fillRect(0, 0, W, H);
  ctx.strokeStyle = 'rgba(150,128,80,.06)'; ctx.lineWidth = 1;
  for (let x = 0; x < W; x += 48) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
  for (let y = 0; y < H; y += 48) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
  ctx.strokeStyle = 'rgba(201,162,39,.13)'; ctx.strokeRect(9, 9, W - 18, H - 18);
  ctx.strokeStyle = 'rgba(201,162,39,.05)'; ctx.strokeRect(15, 15, W - 30, H - 30);
  drawEmbers(0.016);
}
function render() {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  drawBg();
  if (!g.player) return;
  const sx = g.shake ? rnd(-g.shake, g.shake) : 0, sy = g.shake ? rnd(-g.shake, g.shake) : 0;
  ctx.save(); ctx.translate(sx, sy);
  // 区域
  g.zones.forEach(z => {
    const a = Math.min(1, z.t / z.dur) * 0.5 + 0.15;
    ctx.fillStyle = EL[z.el].dim;
    ctx.beginPath(); ctx.arc(z.x, z.y, z.r, 0, TAU); ctx.fill();
    ctx.strokeStyle = EL[z.el].color; ctx.globalAlpha = 0.35 + Math.min(1, z.t) * 0.1;
    ctx.setLineDash([7, 6]); ctx.beginPath(); ctx.arc(z.x, z.y, z.r, 0, TAU); ctx.stroke();
    ctx.setLineDash([]); ctx.globalAlpha = 1;
  });
  // 敌人
  g.enemies.forEach(drawEnemy);
  // 玩家
  drawPlayer();
  // 子弹
  g.bullets.forEach(b => {
    ctx.fillStyle = b.el ? EL[b.el].color : '#f0e6d6';
    ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill();
    ctx.globalAlpha = 0.35;
    ctx.beginPath(); ctx.arc(b.x - b.vx * 0.014, b.y - b.vy * 0.014, b.r * 1.1, 0, TAU); ctx.fill();
    ctx.globalAlpha = 1;
  });
  g.ebullets.forEach(b => {
    ctx.fillStyle = '#ff7a5a';
    ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill();
  });
  // 特效
  g.parts.forEach(p => {
    if (p.ring) {
      ctx.globalAlpha = Math.max(0, p.t / 0.45) * 0.7;
      ctx.strokeStyle = p.color; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, TAU); ctx.stroke();
      ctx.globalAlpha = 1;
    } else if (p.line) {
      ctx.globalAlpha = Math.max(0, p.t / 0.3) * 0.9;
      ctx.strokeStyle = p.color; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(p.x1, p.y1); ctx.lineTo(p.x2, p.y2); ctx.stroke();
      ctx.globalAlpha = 1;
    } else {
      ctx.globalAlpha = Math.max(0, Math.min(1, p.t * 2)) * 0.9;
      ctx.fillStyle = p.color;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, TAU); ctx.fill();
      ctx.globalAlpha = 1;
    }
  });
  // 浮字
  g.texts.forEach(t => {
    ctx.globalAlpha = Math.max(0, Math.min(1, t.t * 1.4));
    ctx.fillStyle = t.color;
    ctx.font = 'bold 15px "SF Mono",Menlo,monospace';
    ctx.textAlign = 'center';
    ctx.fillText(t.txt, t.x, t.y);
    ctx.globalAlpha = 1;
  });
  ctx.restore();
  // 反应提示条
  if (g.banner) {
    const a = Math.min(1, g.banner.t * 2);
    ctx.globalAlpha = a;
    ctx.fillStyle = g.banner.color;
    ctx.font = '600 26px "Songti SC","Noto Serif SC",serif';
    ctx.textAlign = 'center';
    ctx.fillText(g.banner.name, W / 2, 128);
    ctx.font = '13px "PingFang SC",sans-serif';
    ctx.fillStyle = 'rgba(232,225,211,.8)';
    ctx.fillText(g.banner.txt, W / 2, 152);
    ctx.globalAlpha = 1;
  }
  if (g.warn) {
    ctx.fillStyle = 'rgba(255,60,30,' + (0.06 + Math.sin(g.t * 6) * 0.03) + ')';
    ctx.fillRect(0, 0, W, H);
  }
}
function drawEnemy(e) {
  const T = ETYPE[e.type];
  let col = T.color;
  if (e.hurtT > 0.08) col = '#ffffff';
  if (e.totemEl) col = EL[e.totemEl].color;
  if (e.crystalEl) col = EL[e.crystalEl].color;
  const tt = g.t + e.x * 0.01;
  // 底影
  ctx.fillStyle = 'rgba(0,0,0,.4)';
  ctx.beginPath(); ctx.ellipse(e.x, e.y + e.r * 0.8, e.r * 0.95, e.r * 0.42, 0, 0, TAU); ctx.fill();
  // 身体
  ctx.globalAlpha = 0.16;
  ctx.fillStyle = col;
  ctx.beginPath(); ctx.arc(e.x, e.y, e.r * 1.7, 0, TAU); ctx.fill();
  ctx.globalAlpha = 1;
  ctx.fillStyle = col;
  if (T.shape === 'tri') { poly(e.x, e.y, e.r, 3, tt); ctx.fill(); }
  else if (T.shape === 'hex') { poly(e.x, e.y, e.r, 6, tt * 0.6); ctx.fill(); }
  else if (T.shape === 'dia') { poly(e.x, e.y, e.r, 4, Math.PI / 4 + tt * 0.4); ctx.fill(); }
  else { poly(e.x, e.y, e.r, 8, tt * 0.3); ctx.fill(); }
  ctx.strokeStyle = 'rgba(255,245,225,.22)'; ctx.lineWidth = 1;
  ctx.stroke();
  // 内核
  ctx.fillStyle = 'rgba(0,0,0,.55)';
  poly(e.x, e.y, e.r * 0.45, T.shape === 'tri' ? 3 : 6, tt * 1.2 + 1); ctx.fill();
  // 护盾
  if (e.shieldEl) {
    ctx.strokeStyle = EL[e.shieldEl].color;
    ctx.globalAlpha = 0.85; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 7, 0, TAU); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  // 印记
  const marks = ELK.filter(k => e.st[k] && e.st[k].t > 0);
  marks.forEach((k, i) => {
    const a = -Math.PI / 2 + (i - (marks.length - 1) / 2) * 0.42;
    const mx = e.x + Math.cos(a) * (e.r + 13), my = e.y + Math.sin(a) * (e.r + 13);
    ctx.fillStyle = EL[k].color;
    ctx.beginPath(); ctx.arc(mx, my, 3.4, 0, TAU); ctx.fill();
    if (e.st[k].s > 1) {
      ctx.strokeStyle = EL[k].color; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(mx, my, 5.6, 0, TAU); ctx.stroke();
    }
  });
  // 定身 / 破防
  if (e.root > 0) {
    ctx.strokeStyle = '#9ae6ff'; ctx.lineWidth = 1.5; ctx.globalAlpha = 0.7;
    ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 4, 0, TAU); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  // 血条
  if (T.elite || T.boss) {
    const w = e.r * 2.6, hh = 4;
    ctx.fillStyle = 'rgba(0,0,0,.7)';
    ctx.fillRect(e.x - w / 2, e.y - e.r - 16, w, hh);
    ctx.fillStyle = '#ff6b3d';
    ctx.fillRect(e.x - w / 2, e.y - e.r - 16, w * Math.max(0, e.hp / e.maxHp), hh);
    ctx.fillStyle = 'rgba(232,225,211,.65)';
    ctx.font = '10px monospace'; ctx.textAlign = 'center';
    ctx.fillText(T.name, e.x, e.y - e.r - 21);
  }
}
function drawPlayer() {
  const p = g.player;
  if (p.inv > 0 && Math.floor(g.t * 20) % 2 === 0) return;
  const dom = p.mod.prism ? dominantEl() : null;
  ctx.globalAlpha = 0.22;
  ctx.fillStyle = dom ? EL[dom].color : '#ffb08a';
  ctx.beginPath(); ctx.arc(p.x, p.y, 30, 0, TAU); ctx.fill();
  ctx.globalAlpha = 1;
  const grd = ctx.createLinearGradient(p.x, p.y - 14, p.x, p.y + 14);
  grd.addColorStop(0, '#f6e6cf'); grd.addColorStop(1, '#c08b5a');
  ctx.fillStyle = grd;
  ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#2a1d13'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, TAU); ctx.stroke();
  // 面朝
  ctx.fillStyle = '#26180f';
  ctx.beginPath(); ctx.arc(p.x + p.face.x * 0.045, p.y + p.face.y * 0.045, 3.2, 0, TAU); ctx.fill();
  // 元素环
  if (dom) {
    ctx.strokeStyle = EL[dom].color; ctx.globalAlpha = 0.85; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(p.x, p.y, p.r + 6, g.t * 1.4, g.t * 1.4 + 4.2); ctx.stroke();
    ctx.beginPath(); ctx.arc(p.x, p.y, p.r + 6, g.t * 1.4 + Math.PI, g.t * 1.4 + Math.PI + 1.2); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  // 朝向
  const fx = p.face.x, fy = p.face.y, fl = Math.hypot(fx, fy) || 1;
  ctx.fillStyle = 'rgba(255,240,210,.85)';
  ctx.beginPath();
  ctx.moveTo(p.x + fx / fl * (p.r + 9), p.y + fy / fl * (p.r + 9));
  ctx.lineTo(p.x - fy / fl * 4 + fx / fl * (p.r + 2), p.y + fx / fl * 4 + fy / fl * (p.r + 2));
  ctx.lineTo(p.x + fy / fl * 4 + fx / fl * (p.r + 2), p.y - fx / fl * 4 + fy / fl * (p.r + 2));
  ctx.closePath(); ctx.fill();
  // 受伤
  if (p.hurtT > 0) {
    ctx.strokeStyle = 'rgba(255,80,50,' + p.hurtT + ')'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(p.x, p.y, p.r + 3, 0, TAU); ctx.stroke();
  }
}
