/* 余烬回廊 · 元素数据
   项目结构见 README.md；本文件为普通脚本，按 index 中的顺序加载。 */
/* ---------------- 1. 元素 ---------------- */
const EL = {
  fire:  { name: '火', mark: '灼', color: '#ff6b3d', dim: 'rgba(255,107,61,.14)', dur: 4 },
  ice:   { name: '冰', mark: '寒', color: '#4fc3f7', dim: 'rgba(79,195,247,.14)', dur: 4 },
  bolt:  { name: '雷', mark: '导', color: '#b388ff', dim: 'rgba(179,136,255,.14)', dur: 3 },
  venom: { name: '毒', mark: '蚀', color: '#8bd450', dim: 'rgba(139,212,80,.14)', dur: 5 }
};
const ELK = ['fire', 'ice', 'bolt', 'venom'];

/* 反应表：a 元素命中已带 b 印记的目标 */
const REACT = {};
function addR(a, b, d) { REACT[[a, b].sort().join('|')] = d; }
addR('fire', 'ice',   { name: '汽爆', color: '#ffd166', kind: 'vapor',  mul: 3.0, txt: '300% 单体爆发' });
addR('fire', 'bolt',  { name: '过载', color: '#ff9d4d', kind: 'over',   mul: 1.8, txt: '范围爆炸' });
addR('fire', 'venom', { name: '焚尽', color: '#ff7a00', kind: 'burn',   mul: 2.0, txt: '引爆灼层并传染' });
addR('ice', 'bolt',   { name: '超导', color: '#9ae6ff', kind: 'super',  mul: 1.2, txt: '破防 30%' });
addR('ice', 'venom',  { name: '凝滞', color: '#7fe3c0', kind: 'freeze', mul: 1.0, txt: '定身 2s · 毒伤翻倍' });
addR('bolt', 'venom', { name: '蚀雷', color: '#c59bff', kind: 'echain', mul: 1.0, txt: '弹射 3 跳 · 叠蚀' });
const rk = (a, b) => REACT[[a, b].sort().join('|')];

/* ---------------- 2. 被动词条 ---------------- */
const PASK = {
  dmg:   { txt: '全场伤害 +12%',     mod: { dmg: 0.12 } },
  react: { txt: '反应伤害 +25%',     mod: { react: 0.25 } },
  cdr:   { txt: '技能冷却 -12%',     mod: { cdr: 0.12 } },
  hp:    { txt: '最大生命 +18',      mod: { hp: 18 } },
  spd:   { txt: '移动速度 +10%',     mod: { spd: 0.10 } },
  vamp:  { txt: '每次反应回复 4 生', mod: { vamp: 4 } },
  basic: { txt: '普攻伤害 +25%',     mod: { basic: 0.25 } }
};
