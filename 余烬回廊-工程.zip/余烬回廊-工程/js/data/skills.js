/* 余烬回廊 · 技能数据
   项目结构见 README.md；本文件为普通脚本，按 index 中的顺序加载。 */
/* ---------------- 3. 技能池（22 个） ---------------- */
const SKILLS = [
  // 火 —— 爆发与灼烧
  { id:'f_arrow', name:'火矢', el:'fire', rar:1, cd:3.0, kind:'shot', power:1.8, count:1, desc:'射出火矢，命中挂【灼】', pas:'dmg' },
  { id:'f_ring',  name:'烈焰环', el:'fire', rar:1, cd:5.0, kind:'aoe', power:1.5, radius:82, desc:'以自身为中心爆开火环，范围内挂【灼】', pas:'react' },
  { id:'f_core',  name:'熔核', el:'fire', rar:2, cd:6.0, kind:'shot', power:2.2, count:1, splash:62, desc:'熔核命中后小范围爆炸，全部挂【灼】', pas:'hp' },
  { id:'f_wild',  name:'焚原', el:'fire', rar:2, cd:8.0, kind:'zone', power:0.45, radius:95, dur:3.5, tick:0.5, desc:'点燃地面，持续灼烧并叠加【灼】', pas:'vamp' },
  // 冰 —— 控制与破防前置
  { id:'i_spike', name:'冰锥', el:'ice', rar:1, cd:3.0, kind:'shot', power:1.7, count:1, desc:'射出冰锥，命中挂【寒】', pas:'spd' },
  { id:'i_burst', name:'霜爆', el:'ice', rar:1, cd:5.0, kind:'aoe', power:1.4, radius:85, desc:'周身霜爆，挂【寒】并减速 3s', pas:'cdr' },
  { id:'i_blade', name:'霜刃', el:'ice', rar:2, cd:6.0, kind:'dash', power:2.0, len:200, desc:'向目标突进，路径上的敌人受击挂【寒】', pas:'basic' },
  { id:'i_field', name:'寒域', el:'ice', rar:2, cd:8.0, kind:'zone', power:0.35, radius:100, dur:3.5, tick:0.5, desc:'寒霜领域，持续施【寒】并拖慢敌人', pas:'dmg' },
  // 雷 —— 连锁与破防
  { id:'b_arc',   name:'电弧', el:'bolt', rar:1, cd:3.0, kind:'chain', power:1.2, jumps:2, desc:'电弧在 2 名敌人之间跳跃', pas:'react' },
  { id:'b_strike',name:'落雷', el:'bolt', rar:1, cd:5.5, kind:'strike', power:2.0, radius:58, desc:'雷击落在最近的敌人，范围挂【导】', pas:'dmg' },
  { id:'b_net',   name:'雷网', el:'bolt', rar:2, cd:6.5, kind:'chain', power:1.3, jumps:4, desc:'连锁最多 4 名敌人，跳数越多越痛', pas:'cdr' },
  { id:'b_static',name:'静电环', el:'bolt', rar:2, cd:6.0, kind:'aoe', power:1.6, radius:95, desc:'环身放电，范围内全部挂【导】', pas:'basic' },
  // 毒 —— 易伤与持续
  { id:'v_sting', name:'毒刺', el:'venom', rar:1, cd:3.0, kind:'shot', power:1.6, count:1, desc:'射出毒刺，命中挂【蚀】', pas:'spd' },
  { id:'v_mist',  name:'毒雾', el:'venom', rar:1, cd:5.0, kind:'aoe', power:1.3, radius:90, desc:'毒雾爆开，范围内挂【蚀】', pas:'vamp' },
  { id:'v_seed',  name:'蚀种', el:'venom', rar:2, cd:7.0, kind:'shot', power:1.5, count:1, splash:50, zone:60, desc:'命中处留下 3s 毒池，持续叠【蚀】', pas:'react' },
  { id:'v_rain',  name:'腐雨', el:'venom', rar:2, cd:8.0, kind:'zone', power:0.4, radius:110, dur:4.0, tick:0.5, desc:'腐蚀之雨，长时叠【蚀】并持续伤害', pas:'hp' },
  // 紫 —— 改变规则
  { id:'p_prism', name:'三色棱镜', el:null, rar:3, kind:'passive', mod:{ prism:true }, desc:'普攻附加你当前最多的元素，让基础攻击也能起反应', pasTxt:'规则：普攻可触发元素反应' },
  { id:'p_chain', name:'连锁反应', el:null, rar:3, kind:'passive', mod:{ chain:true }, desc:'每次触发元素反应，全部技能冷却立刻 -1.5s', pasTxt:'规则：反应即刷新技能' },
  { id:'p_vamp',  name:'余烬吸血', el:null, rar:3, kind:'passive', mod:{ vamp:7 }, desc:'每次触发元素反应回复 7 点生命', pasTxt:'规则：反应即续航' },
  { id:'p_focus', name:'反应专精', el:null, rar:3, kind:'passive', mod:{ react:0.6 }, desc:'元素反应造成的伤害 +60%（乘算）', pasTxt:'规则：只吃反应' },
  { id:'p_hunt',  name:'猎杀本能', el:null, rar:3, kind:'passive', mod:{ dmg:0.35, hp:-10 }, desc:'所有伤害 +35%，但最大生命 -10', pasTxt:'规则：高风险高回报' },
  { id:'p_swift', name:'疾风之息', el:null, rar:3, kind:'passive', mod:{ spd:0.25, dash:2 }, desc:'移速 +25%，冲刺冷却减少 2s', pasTxt:'规则：用走位换输出' }
];
const SKMAP = {};
SKILLS.forEach(s => SKMAP[s.id] = s);
const STARTER = ['f_arrow','f_ring','i_spike','i_burst','b_arc','b_strike','v_sting','v_mist'];
