/* 余烬回廊 · 关卡数据
   项目结构见 README.md；本文件为普通脚本，按 index 中的顺序加载。 */
/* ---------------- 4. 敌人 / 房间 ---------------- */
const ETYPE = {
  g:    { name:'烬兽',   r:12, spd:80,  dmg:4,  color:'#bda88c', shape:'tri' },
  h:    { name:'铸怪',   r:15, spd:52,  dmg:4,  color:'#5fb3a0', shape:'hex', healer:true },
  e:    { name:'守关者', r:23, spd:58,  dmg:10, color:'#d8a13c', shape:'oct', elite:true },
  boss: { name:'回廊之主', r:36, spd:50, dmg:18, color:'#ff5a3c', shape:'oct', boss:true },
  cr:   { name:'元素晶石', r:14, spd:0, dmg:0, color:'#9ad9ff', shape:'dia', crystal:true }
};
const ROOMS = [
  { name:'房间一 · 灰烬庭院', lim:70, hp:{ g:60 },
    waves:[[{t:'g',n:7}],[{t:'g',n:7}],[{t:'g',n:7}]] },
  { name:'房间二 · 铸炉回廊', lim:85, hp:{ g:90, h:240 },
    waves:[[{t:'g',n:8}],[{t:'g',n:8},{t:'h',n:1}],[{t:'g',n:8}]] },
  { name:'房间三 · 守关者之厅', lim:100, hp:{ g:240, e:2800 },
    waves:[[{t:'g',n:5},{t:'e',n:1}]] },
  { name:'房间四 · 抉择之室', lim:40, choice:true },
  { name:'房间五 · 余烬祭坛', lim:110, hp:{ g:330, e:5500 },
    waves:[[{t:'g',n:7},{t:'e',n:1}]], crystals:true }
];

/* 图腾（Boss 二阶段召唤物） */
ETYPE.t = { name:'元素图腾', r:16, spd:0, dmg:0, color:'#e8e1d3', shape:'dia', totem:true };
