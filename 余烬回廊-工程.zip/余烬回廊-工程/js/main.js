/* 余烬回廊 · 入口
   项目结构见 README.md；本文件为普通脚本，按 index 中的顺序加载。 */
/* ---------------- 18. 主循环 ---------------- */
const keys = {};
const touch = { x: null, y: null };
function update(dt) {
  const p = g.player;
  if (!p) return;
  // 移动
  let mx = 0, my = 0;
  if (keys.a || keys.arrowleft) mx--;
  if (keys.d || keys.arrowright) mx++;
  if (keys.w || keys.arrowup) my--;
  if (keys.s || keys.arrowdown) my++;
  if (touch.x !== null) {
    const dx = touch.x - p.x, dy = touch.y - p.y, d = Math.hypot(dx, dy);
    if (d > 14) { mx = dx / d; my = dy / d; }
  }
  const ml = Math.hypot(mx, my);
  if (ml > 0) {
    mx /= ml; my /= ml;
    p.x += mx * p.spd * dt;
    p.y += my * p.spd * dt;
    p.face = { x: mx, y: my };
  }
  p.x = clamp(p.x, 18, W - 18);
  p.y = clamp(p.y, 18, H - 18);
  p.inv -= dt; p.hurtT -= dt; p.dashT -= dt;
  // 冲刺
  if (keys[' '] && p.dashT <= 0) {
    p.dashT = p.dashCd;
    const a = Math.atan2(p.face.y, p.face.x);
    p.x = clamp(p.x + Math.cos(a) * 130, 18, W - 18);
    p.y = clamp(p.y + Math.sin(a) * 130, 18, H - 18);
    p.inv = 0.3;
    for (let i = 0; i < 6; i++) g.parts.push({ x: p.x - Math.cos(a) * i * 12, y: p.y - Math.sin(a) * i * 12, vx: 0, vy: 0, color: '#f6e6cf', t: 0.3, size: 3 });
  }
  // 普攻
  p.atk.t -= dt;
  if (p.atk.t <= 0) {
    const t = nearest(p.x, p.y, 320);
    if (t) {
      const ang = Math.atan2(t.y - p.y, t.x - p.x);
      const el = p.mod.prism ? dominantEl() : null;
      g.bullets.push({ x: p.x, y: p.y, vx: Math.cos(ang) * 460, vy: Math.sin(ang) * 460, el, dmg: p.atk.dmg * (1 + p.mod.basic) * dmgMul(), r: 5, life: 0.9, splash: 0, zone: 0 });
      p.atk.t = p.atk.cd;
      p.face = { x: Math.cos(ang), y: Math.sin(ang) };
    }
  }
  // 冷却
  p.skills.forEach(s => { if (s.t > 0) s.t = Math.max(0, s.t - dt); });
  // 子弹
  for (let i = g.bullets.length - 1; i >= 0; i--) {
    const b = g.bullets[i];
    b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
    let hit = false;
    for (const e of g.enemies) {
      if (e.dead) continue;
      if (Math.hypot(e.x - b.x, e.y - b.y) < e.r + b.r) {
        hit = true;
        if (e.type === 'cr') {
          if (b.el === e.crystalEl) { e.hp = 0; killEnemy(e); }
          hit = false; // 晶石不对元素则子弹穿过
          continue;
        }
        takeHit(e, b.dmg, b.el);
        if (b.splash) explosion(b.x, b.y, b.splash, b.el || 'fire', b.dmg * 0.6);
        if (b.zone) g.zones.push({ x: b.x, y: b.y, r: b.zone, el: b.el, dmg: b.dmg * 0.5, t: 2.5, dur: 2.5, tick: 0.5, acc: 0 });
        break;
      }
    }
    if (hit || b.life <= 0 || b.x < -20 || b.x > W + 20 || b.y < -20 || b.y > H + 20) g.bullets.splice(i, 1);
  }
  // 敌方子弹
  for (let i = g.ebullets.length - 1; i >= 0; i--) {
    const b = g.ebullets[i];
    b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
    if (Math.hypot(b.x - p.x, b.y - p.y) < p.r + b.r) { hurtPlayer(b.dmg); g.ebullets.splice(i, 1); continue; }
    if (b.life <= 0 || b.x < -30 || b.x > W + 30 || b.y < -30 || b.y > H + 30) g.ebullets.splice(i, 1);
  }
  // 敌人
  g.enemies.forEach(e => updateEnemy(e, dt));
  g.enemies = g.enemies.filter(e => !e.dead);
  // 区域
  for (let i = g.zones.length - 1; i >= 0; i--) {
    const z = g.zones[i];
    z.t -= dt; z.acc += dt;
    if (z.acc >= z.tick) {
      z.acc = 0;
      enemiesIn(z.x, z.y, z.r).forEach(e => takeHit(e, z.dmg, z.el));
    }
    if (z.t <= 0) g.zones.splice(i, 1);
  }
  // 粒子
  for (let i = g.parts.length - 1; i >= 0; i--) {
    const q = g.parts[i]; q.t -= dt;
    if (q.ring) { q.r += (q.max - q.r) * dt * 8; }
    else if (!q.line) { q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= 0.94; q.vy *= 0.94; }
    if (q.t <= 0) g.parts.splice(i, 1);
  }
  for (let i = g.texts.length - 1; i >= 0; i--) {
    const t = g.texts[i]; t.t -= dt; t.y += t.dy * dt;
    if (t.t <= 0) g.texts.splice(i, 1);
  }
  if (g.banner) { g.banner.t -= dt; if (g.banner.t <= 0) g.banner = null; }
  if (g.shake > 0) g.shake = Math.max(0, g.shake - dt * 22);
  // 房间
  if (g.state === 'playing') {
    roomTick(dt);
    if (g.bossDead) victory();
  }
  if (g.pending) {
    g.pending.t -= dt;
    if (g.pending.t <= 0) { const fn = g.pending.fn; g.pending = null; fn(); }
  }
  if (g.player.hp <= 0 && g.state === 'playing') gameOver();
}
function updateHUD() {
  $('hud').style.opacity = g.player ? '1' : '0';
  const p = g.player;
  if (!p) {
    $('hpbar').style.transform = 'scaleX(1)';
    return;
  }
  $('hpbar').style.transform = 'scaleX(' + clamp(p.hp / p.maxHp, 0, 1) + ')';
  $('hptext').textContent = Math.ceil(p.hp) + ' / ' + p.maxHp;
  $('crystals').textContent = g.run.crystals;
  $('cores').textContent = g.run.cores;
  $('timer').textContent = fmt(g.elapsed);
  const slots = $('skillbar').children;
  for (let i = 0; i < slots.length; i++) {
    const sk = p.skills[i], fill = slots[i].querySelector('.cd');
    if (sk && fill) {
      const r = sk.t / (sk.cdMax || 1);
      fill.style.transform = 'scaleY(' + clamp(r, 0, 1) + ')';
    }
  }
}
function renderSkillbar() {
  const bar = $('skillbar');
  bar.innerHTML = '';
  const p = g.player;
  for (let i = 0; i < 5; i++) {
    const sk = p ? p.skills[i] : null;
    const d = document.createElement('div');
    d.className = 'slot' + (sk ? ' on' : ' empty');
    if (sk) {
      const c = sk.ref.el ? EL[sk.ref.el].color : '#c9a227';
      d.innerHTML = `<div class="elbar" style="background:${c}"></div>
        <div class="rar" style="color:${sk.ref.rar === 3 ? '#c9a227' : sk.ref.rar === 2 ? '#7fb3ff' : '#7a7364'}">${'★'.repeat(sk.ref.rar)}</div>
        <div class="key">${i + 1}</div><div class="cd" style="display:none"></div>
        <div class="nm">${sk.ref.name}</div>`;
      if (sk.ref.el) d.style.borderColor = 'rgba(255,255,255,.12)';
      d.onclick = () => castSkill(i);
    } else {
      d.innerHTML = `<div class="key">${i + 1}</div><div class="nm" style="opacity:.35">空</div>`;
    }
    bar.appendChild(d);
  }
}
let last = performance.now();
function loop(now) {
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  g.t += dt;
  if (g.state === 'playing') {
    g.elapsed += dt;
    update(dt);
  } else {
    if (g.pending) {
      g.pending.t -= dt;
      if (g.pending.t <= 0) { const fn = g.pending.fn; g.pending = null; fn(); }
    }
    if (g.shake > 0) g.shake = Math.max(0, g.shake - dt * 22);
    if (g.banner) { g.banner.t -= dt; if (g.banner.t <= 0) g.banner = null; }
  }
  render();
  updateHUD();
  requestAnimationFrame(loop);
}

/* ---------------- 19. 输入 ---------------- */
function toCanvas(ev) {
  const r = cv.getBoundingClientRect();
  return { x: (ev.clientX - r.left) / r.width * W, y: (ev.clientY - r.top) / r.height * H };
}
window.addEventListener('keydown', e => {
  const k = e.key.toLowerCase();
  keys[k] = true;
  keys[e.key] = true;
  if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
  const n = parseInt(e.key, 10);
  if (n >= 1 && n <= 5) castSkill(n - 1);
});
window.addEventListener('keyup', e => {
  keys[e.key.toLowerCase()] = false;
  keys[e.key] = false;
});
cv.addEventListener('pointerdown', e => {
  if (g.state !== 'playing') return;
  const pt = toCanvas(e);
  touch.x = pt.x; touch.y = pt.y;
  cv.setPointerCapture(e.pointerId);
});
cv.addEventListener('pointermove', e => {
  if (touch.x === null) return;
  const pt = toCanvas(e);
  touch.x = pt.x; touch.y = pt.y;
});
cv.addEventListener('pointerup', () => { touch.x = null; touch.y = null; });
cv.addEventListener('pointercancel', () => { touch.x = null; touch.y = null; });

/* ---------------- 20. 启动 ---------------- */
renderSkillbar();
openTitle();
requestAnimationFrame(loop);
