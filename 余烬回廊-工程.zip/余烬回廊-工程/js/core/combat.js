/* 余烬回廊 · 战斗
   项目结构见 README.md；本文件为普通脚本，按 index 中的顺序加载。 */
/* ---------------- 7. 伤害 / 印记 / 反应 ---------------- */
function nearest(x, y, maxR) {
  let best = null, bd = (maxR || 9999) ** 2;
  for (const e of g.enemies) {
    if (e.dead || e.type === 'cr') continue;
    const d = (e.x - x) ** 2 + (e.y - y) ** 2;
    if (d < bd) { bd = d; best = e; }
  }
  return best;
}
function enemiesIn(x, y, r) {
  return g.enemies.filter(e => !e.dead && e.type !== 'cr' && Math.hypot(e.x - x, e.y - y) < r + e.r);
}
function enemyMul(e, el) {
  let m = 1;
  if (e.venomStacks) m *= 1 + 0.08 * Math.min(3, e.venomStacks);
  if (e.defDown > 0) m *= 1.3;
  if (e.shieldEl) m *= (el === e.shieldEl ? 0.25 : 0.72);
  if (e.totemEl) m *= (el === e.totemEl ? 0.1 : 1);
  if (e.boss && g.run.totems.length > 0) m *= 0.45;
  return m;
}
function applyMark(e, el) {
  const st = e.st[el] || (e.st[el] = { s: 0, t: 0 });
  st.s = Math.min(3, st.s + 1);
  st.t = EL[el].dur;
  if (el === 'venom') e.venomStacks = st.s;
}
function rawDamage(e, amount) {
  if (!e || e.dead) return;
  const d = Math.max(1, amount * enemyMul(e, null));
  e.hp -= d; e.hurtT = 0.15;
  floatText(e.x, e.y - e.r - 4, Math.round(d), '#ffe6c7');
  if (e.hp <= 0) killEnemy(e);
}
function takeHit(e, amount, el) {
  if (!e || e.dead) return;
  const dmg = Math.max(1, amount * enemyMul(e, el));
  e.hp -= dmg; e.hurtT = 0.15;
  floatText(e.x, e.y - e.r - 4, Math.round(dmg), el ? EL[el].color : '#f0e6d6');
  if (el) {
    const others = ELK.filter(k => k !== el && e.st[k] && e.st[k].t > 0);
    if (others.length && (g.t - (e.lastR || -9)) > 0.5 && !(e.shieldEl && el === e.shieldEl)) {
      const other = others[0];
      delete e.st[other];
      e.lastR = g.t;
      doReact(e, el, other, amount);
    }
    if (e.dead) return;
    applyMark(e, el);
  }
  if (e.hp <= 0) killEnemy(e);
}
function doReact(e, a, b, src) {
  const r = rk(a, b); if (!r) return;
  const rb = src * r.mul * reactMul();
  g.banner = { name: r.name, color: r.color, txt: r.txt, t: 1.5 };
  g.shake = Math.max(g.shake, 7);
  burst(e.x, e.y, r.color, 16);
  if (e.shieldEl) {
    e.shieldEl = null;
    floatText(e.x, e.y - e.r - 24, '护盾破碎', '#ffd166');
    g.shake = Math.max(g.shake, 7);
  }
  if (g.player.mod.vamp) healPlayer(g.player.mod.vamp);
  if (g.player.mod.chain) g.player.skills.forEach(s => { s.t = Math.max(0, s.t - 1.5); });
  switch (r.kind) {
    case 'vapor':
      rawDamage(e, rb);
      e.kx = e.x + 40; e.ky = e.y;
      break;
    case 'over': {
      const list = enemiesIn(e.x, e.y, 95);
      list.forEach(o => rawDamage(o, rb * 0.85));
      shock(e.x, e.y, 95, r.color);
      break;
    }
    case 'burn': {
      const stacks = Math.max(1, (e.st.fire ? e.st.fire.s : 1));
      rawDamage(e, rb * stacks * 0.7);
      shock(e.x, e.y, 88, r.color);
      enemiesIn(e.x, e.y, 88).forEach(o => { if (o !== e) applyMark(o, 'fire'); });
      break;
    }
    case 'super': {
      enemiesIn(e.x, e.y, 100).forEach(o => { o.defDown = 6; });
      rawDamage(e, rb * 0.6);
      shock(e.x, e.y, 100, r.color);
      break;
    }
    case 'freeze':
      e.root = 2; e.vulnT = 2.5; e.frozen = 2.5;
      rawDamage(e, rb * 0.8);
      break;
    case 'echain': {
      let from = { x: e.x, y: e.y }, cur = e;
      const seen = new Set([e]);
      for (let j = 0; j < 3; j++) {
        const nx = g.enemies.filter(o => !o.dead && o.type !== 'cr' && !seen.has(o))
          .sort((x, y) => dist(from, x) - dist(from, y))[0];
        if (!nx) break;
        seen.add(nx);
        lightning(from.x, from.y, nx.x, nx.y, r.color);
        rawDamage(nx, rb * 0.8);
        applyMark(nx, 'venom');
        from = { x: nx.x, y: nx.y };
      }
      break;
    }
  }
}
function killEnemy(e) {
  if (e.dead) return;
  e.dead = true;
  burst(e.x, e.y, ETYPE[e.type].color, 10);
  if (e.type === 'cr') { // 元素晶石被正确元素击碎 → 大范围爆炸
    shock(e.x, e.y, 130, '#9ad9ff');
    enemiesIn(e.x, e.y, 130).forEach(o => rawDamage(o, 320));
    return;
  }
  if (e.totemEl) {
    g.run.totems = g.run.totems.filter(t => t !== e);
    floatText(e.x, e.y - 20, '图腾崩解', '#ffd166');
    g.shake = Math.max(g.shake, 6);
    return;
  }
  const gain = e.type === 'e' ? 15 : e.type === 'boss' ? 40 : e.type === 'h' ? 3 : ri(1, 3);
  g.run.crystals += gain;
  floatText(e.x, e.y, '+' + gain, '#c9a227');
  if (e.type === 'e') g.run.cores += 1;
  if (e.type === 'boss') { g.run.cores += 2; g.bossDead = true; }
}

/* ---------------- 8. 特效 ---------------- */
function floatText(x, y, txt, color) {
  g.texts.push({ x, y, txt: String(txt), color, t: 0.9, dy: -30 });
}
function burst(x, y, color, n) {
  for (let i = 0; i < n; i++) {
    const a = rnd(0, TAU), sp = rnd(40, 170);
    g.parts.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, color, t: rnd(0.3, 0.7), size: rnd(1.5, 3.5) });
  }
}
function shock(x, y, r, color) {
  g.parts.push({ ring: true, x, y, r: 8, max: r, color, t: 0.45 });
}
function lightning(x1, y1, x2, y2, color) {
  g.parts.push({ line: true, x1, y1, x2, y2, color, t: 0.22 });
}

/* ---------------- 9. 施法 ---------------- */
function castSkill(i) {
  const p = g.player;
  if (!p || g.state !== 'playing') return;
  const sk = p.skills[i];
  if (!sk || sk.t > 0) return;
  const ref = sk.ref;
  const cd = ref.cd * coolMul();
  sk.t = cd; sk.cdMax = cd;
  const base = p.atk.dmg * ref.power * (1 + (sk.lv - 1) * 0.3) * (ref.kind === 'passive' ? 1 : dmgMul());
  const t = nearest(p.x, p.y, 1400);
  switch (ref.kind) {
    case 'shot': {
      const n = ref.count || 1;
      for (let k = 0; k < n; k++) {
        let ang;
        if (t) ang = Math.atan2(t.y - p.y, t.x - p.x) + (k - (n - 1) / 2) * 0.18;
        else ang = Math.atan2(p.face.y, p.face.x);
        g.bullets.push({ x: p.x, y: p.y, vx: Math.cos(ang) * 560, vy: Math.sin(ang) * 560, el: ref.el, dmg: base, r: 7, life: 1.1, splash: ref.splash || 0, zone: ref.zone || 0 });
      }
      break;
    }
    case 'aoe':
      explosion(p.x, p.y, ref.radius, ref.el, base);
      break;
    case 'zone':
      g.zones.push({ x: p.x, y: p.y, r: ref.radius, el: ref.el, dmg: base, t: ref.dur, dur: ref.dur, tick: ref.tick || 0.5, acc: 0 });
      break;
    case 'dash': {
      let ang = t ? Math.atan2(t.y - p.y, t.x - p.x) : Math.atan2(p.face.y, p.face.x);
      const x2 = clamp(p.x + Math.cos(ang) * ref.len, 24, W - 24);
      const y2 = clamp(p.y + Math.sin(ang) * ref.len, 24, H - 24);
      for (let i = 0; i < 10; i++) {
        const k = i / 10;
        g.parts.push({ x: p.x + (x2 - p.x) * k, y: p.y + (y2 - p.y) * k, vx: 0, vy: 0, color: EL[ref.el].color, t: 0.3, size: 3 });
      }
      g.enemies.forEach(e => {
        if (e.dead || e.type === 'cr') return;
        const d = segDist(e.x, e.y, p.x, p.y, x2, y2);
        if (d < 40 + e.r) takeHit(e, base, ref.el);
      });
      p.x = x2; p.y = y2;
      break;
    }
    case 'chain': {
      let from = { x: p.x, y: p.y }, cur = t;
      const seen = new Set();
      for (let j = 0; j < ref.jumps; j++) {
        if (!cur) break;
        seen.add(cur);
        lightning(from.x, from.y, cur.x, cur.y, EL[ref.el].color);
        takeHit(cur, base * (j === 0 ? 1 : 0.85), ref.el);
        from = { x: cur.x, y: cur.y };
        cur = g.enemies.filter(o => !o.dead && o.type !== 'cr' && !seen.has(o))
          .sort((a, b) => dist(from, a) - dist(from, b))[0];
      }
      break;
    }
    case 'strike': {
      if (!t) break;
      explosion(t.x, t.y, ref.radius, ref.el, base);
      g.parts.push({ line: true, x1: t.x, y1: 0, x2: t.x, y2: t.y, color: EL[ref.el].color, t: 0.3 });
      break;
    }
  }
  p.face = t ? { x: t.x - p.x, y: t.y - p.y } : p.face;
}
function segDist(px, py, x1, y1, x2, y2) {
  const dx = x2 - x1, dy = y2 - y1;
  const len = Math.hypot(dx, dy) || 1;
  let t = ((px - x1) * dx + (py - y1) * dy) / (len * len);
  t = clamp(t, 0, 1);
  return Math.hypot(px - (x1 + dx * t), py - (y1 + dy * t));
}
function explosion(x, y, r, el, dmg) {
  shock(x, y, r, EL[el].color);
  burst(x, y, EL[el].color, 12);
  enemiesIn(x, y, r).forEach(e => takeHit(e, dmg, el));
  g.shake = Math.max(g.shake, 3);
}

/* ---------------- 10. 敌人行为 ---------------- */
function edgePos() {
  const m = 24;
  switch (ri(0, 3)) {
    case 0: return { x: rnd(m, W - m), y: m };
    case 1: return { x: rnd(m, W - m), y: H - m };
    case 2: return { x: m, y: rnd(m, H - m) };
    default: return { x: W - m, y: rnd(m, H - m) };
  }
}
function spawnEnemy(type, hp, opts) {
  const T = ETYPE[type];
  const pos = edgePos();
  const e = Object.assign({
    type, x: pos.x, y: pos.y, r: T.r, hp, maxHp: hp, spd: T.spd, dmg: T.dmg,
    st: {}, defDown: 0, root: 0, vulnT: 0, venomStacks: 0, cdT: 0.6,
    dead: false, dieT: 0, hurtT: 0, die: false
  }, opts || {});
  if (T.elite && !e.shieldEl) e.shieldEl = pick(ELK);
  g.enemies.push(e);
  return e;
}
function updateEnemy(e, dt) {
  if (e.dead) return;
  const p = g.player;
  const d = dist(e, p);
  for (const k of ELK) {
    if (e.st[k]) {
      e.st[k].t -= dt;
      if (e.st[k].t <= 0) { delete e.st[k]; if (k === 'venom') e.venomStacks = 0; }
    }
  }
  if (e.defDown > 0) e.defDown -= dt;
  if (e.vulnT > 0) e.vulnT -= dt;
  if (e.root > 0) e.root -= dt;
  e.hurtT = Math.max(0, e.hurtT - dt);
  // 持续伤害
  if (e.st.fire) {
    e.dotAcc = (e.dotAcc || 0) + dt * e.st.fire.s * 0.005 * e.maxHp;
    if (e.dotAcc > 8) { rawDamage(e, e.dotAcc); e.dotAcc = 0; }
  }
  if (e.dead || e.type === 'cr') return;
  // 移动
  const slowK = (e.st.ice && e.st.ice.t > 0 ? 0.72 : 1) * (e.root > 0 ? 0 : 1);
  if (e.spd > 0 && d > e.r + p.r + 2) {
    const a = Math.atan2(p.y - e.y, p.x - e.x);
    e.x += Math.cos(a) * e.spd * slowK * dt;
    e.y += Math.sin(a) * e.spd * slowK * dt;
  }
  // 接触伤害
  e.cdT -= dt;
  if (e.dmg > 0 && d < e.r + p.r + 2 && e.cdT <= 0) {
    hurtPlayer(e.dmg); e.cdT = 1.3;
  }
  // 铸怪治疗
  if (ETYPE[e.type].healer) {
    e.hT = (e.hT || 0) - dt;
    if (e.hT <= 0) {
      e.hT = 1.2;
      g.enemies.forEach(o => { if (o !== e && !o.dead && dist(o, e) < 140) o.hp = Math.min(o.maxHp, o.hp + 14); });
      g.parts.push({ ring: true, x: e.x, y: e.y, r: 8, max: 140, color: '#5fb3a0', t: 0.5 });
    }
  }
  // 精英 / Boss 远程攻击
  if (e.type === 'e' || e.type === 'boss') {
    e.shT = (e.shT || 0) - dt;
    if (e.shT <= 0 && d < 620) {
      e.shT = e.type === 'boss' ? 2.4 : 3.8;
      const n = e.type === 'boss' ? 9 : 2;
      for (let i = 0; i < n; i++) {
        const a = e.type === 'boss' ? (i / n) * TAU + rnd(-0.1, 0.1) : Math.atan2(p.y - e.y, p.x - e.x) + (i - 1) * 0.22;
        g.ebullets.push({ x: e.x, y: e.y, vx: Math.cos(a) * 210, vy: Math.sin(a) * 210, dmg: 6, r: 6, life: 2.6 });
      }
      shock(e.x, e.y, 40, '#ff8a6a');
    }
  }
  // Boss 二阶段
  if (e.type === 'boss' && e.phase !== 2 && e.hp < e.maxHp * 0.5) {
    e.phase = 2;
    g.banner = { name: '图腾觉醒', color: '#ff5a3c', txt: '击碎与你元素不同的图腾才能破防', t: 2.2 };
    g.shake = 10;
    const pts = [{ x: 180, y: 150 }, { x: W - 180, y: 150 }, { x: 180, y: H - 150 }, { x: W - 180, y: H - 150 }];
    const els = ['fire', 'ice', 'bolt', 'venom'].sort(() => Math.random() - 0.5);
    pts.forEach((pt, i) => {
      const t = spawnEnemy('t', 500, { x: pt.x, y: pt.y, totemEl: els[i], r: 17 });
      g.run.totems.push(t);
    });
  }
}

/* ---------------- 11. 玩家受击 / 治疗 ---------------- */
function hurtPlayer(v) {
  const p = g.player;
  if (p.inv > 0 || (g.state !== 'playing' && g.state !== 'choice')) return;
  p.hp -= v; p.inv = 0.3; p.hurtT = 0.3;
  g.shake = Math.max(g.shake, 5);
  floatText(p.x, p.y - 24, '-' + Math.round(v), '#ff8a6a');
  if (p.hp <= 0) { p.hp = 0; gameOver(); }
}
function healPlayer(v) {
  const p = g.player;
  p.hp = Math.min(p.maxHp, p.hp + v);
  floatText(p.x, p.y - 26, '+' + Math.round(v), '#8bd450');
}
