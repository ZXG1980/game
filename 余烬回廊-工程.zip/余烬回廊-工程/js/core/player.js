/* 余烬回廊 · 玩家
   项目结构见 README.md；本文件为普通脚本，按 index 中的顺序加载。 */
/* ---------------- 6. 玩家 ---------------- */


function newPlayer() {
  return {
    x: W / 2, y: H / 2 + 40, r: 13, hp: 130, maxHp: 130, spd: 215,
    mod: { dmg:0, react:0, cdr:0, hp:0, spd:0, vamp:0, basic:0, prism:false, chain:false, dash:0 },
    skills: [], passives: [], atk: { dmg: 12, cd: 0.55, t: 0 },
    dashCd: 3.2, dashT: 0, inv: 0, hurtT: 0, face: { x: 0, y: -1 }, move: { x: 0, y: 0 }
  };
}
function recompute() {
  const p = g.player, oldMax = p.maxHp;
  p.maxHp = Math.max(40, Math.round(130 + p.mod.hp));
  if (p.maxHp > oldMax) p.hp += p.maxHp - oldMax;
  p.hp = Math.min(p.hp, p.maxHp);
  p.spd = 215 * (1 + p.mod.spd);
  p.dashCd = Math.max(1.2, 3.2 - (p.mod.dash || 0));
}
function addSkill(sk) {
  const p = g.player;
  if (sk.kind === 'passive') {
    p.passives.push(sk);
    for (const k in sk.mod) {
      const v = sk.mod[k];
      if (typeof v === 'boolean') p.mod[k] = p.mod[k] || v;
      else p.mod[k] = (p.mod[k] || 0) + v;
    }
  } else {
    p.skills.push({ ref: sk, t: 0, cdMax: 1, lv: 1 });
  }
  recompute();
}
const dmgMul = () => 1 + g.player.mod.dmg;
const reactMul = () => 1 + g.player.mod.react;
const coolMul = () => Math.max(0.55, 1 - g.player.mod.cdr);

function dominantEl() {
  const c = { fire: 0, ice: 0, bolt: 0, venom: 0 };
  g.player.skills.forEach(s => { if (s.ref.el) c[s.ref.el] += 1.6; });
  g.player.passives.forEach(s => { if (s.el) c[s.el] += 1; });
  let best = 'fire';
  for (const k of ELK) if (c[k] > c[best]) best = k;
  return best;
}
