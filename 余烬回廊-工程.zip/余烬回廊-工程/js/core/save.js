/* 余烬回廊 · 存档
   项目结构见 README.md；本文件为普通脚本，按 index 中的顺序加载。 */
/* ---------------- 5. 存档 ---------------- */
const SKEY = 'ember_corridor_v1';
const DEFAULT_META = { crystals: 0, cores: 0, unlocked: STARTER.slice(), prefs: [], clears: 0, runs: 0 };
let meta = loadMeta();
function loadMeta() {
  try {
    const s = JSON.parse(localStorage.getItem(SKEY));
    if (s && Array.isArray(s.unlocked)) return Object.assign({}, DEFAULT_META, s);
  } catch (e) {}
  return JSON.parse(JSON.stringify(DEFAULT_META));
}
function saveMeta() { try { localStorage.setItem(SKEY, JSON.stringify(meta)); } catch (e) {} }
function costOf(sk) { return sk.rar === 3 ? { c: 120, k: 3 } : sk.rar === 2 ? { c: 55, k: 1 } : { c: 25, k: 0 }; }

/* 游戏状态容器 */
const g = {
  state: 'title', t: 0, stage: 0, roomT: 0, wave: 0, waveT: 0,
  player: null, enemies: [], bullets: [], ebullets: [], zones: [], texts: [], parts: [], crystals: [],
  shake: 0, flash: null, banner: null, elapsed: 0, warn: 0,
  run: { crystals: 0, cores: 0, rerolls: 2, totems: [], boss: null }
};
