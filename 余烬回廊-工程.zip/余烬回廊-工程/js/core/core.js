/* 余烬回廊 · 基础工具
   项目结构见 README.md；本文件为普通脚本，按 index 中的顺序加载。 */
/* ---------------- 0. 基础 ---------------- */
const cv = document.getElementById('cv');
const ctx = cv.getContext('2d');
const W = 960, H = 600, TAU = Math.PI * 2;
const rnd = (a, b) => a + Math.random() * (b - a);
const ri = (a, b) => Math.floor(rnd(a, b + 1));
const pick = a => a[Math.floor(Math.random() * a.length)];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const $ = id => document.getElementById(id);
